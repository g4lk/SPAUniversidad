# SPAFlickr
A SPA Flickr API for university project.
